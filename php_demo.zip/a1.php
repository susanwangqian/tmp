<head>
        <title>a1: bare bones</title>
</head>
<body>
<?php
     echo "<h2>a1 Results Page</h2>";
     echo "You clicked a button!";
?>
</body>