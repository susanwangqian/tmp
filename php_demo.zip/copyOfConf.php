
<?php
	//these are credentials which will be used by open.php to create connection to dbase
	//make updates here as noted below, and save this file as conf.php
	$dbhost = "dbase.cs.jhu.edu"; // database host
	$dbuser = "22sp_jhopkin1";    // username on db host: replace 22sp_jhopkin1 with yours
	$dbpass = "*****";            // password on db host: replace ***** with yours
	$dbname = "22sp_jhopkin1_db"; // the db's name: replace 22sp_jhopkin1_db with yours
?>
